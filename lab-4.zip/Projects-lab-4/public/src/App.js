import './style.css';
import LongPollingChat from './long-polling';

const App = () => {

  return (
    <LongPollingChat />
  );
};

export default App;
