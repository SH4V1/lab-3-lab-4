Steps:
1. npm init
2. npm i express
3. Create index.js